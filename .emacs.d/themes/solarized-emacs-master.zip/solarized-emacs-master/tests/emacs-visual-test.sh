#!/bin/sh

emacs -q -l emacs-visual-test.el
